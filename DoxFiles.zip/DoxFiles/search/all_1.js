var searchData=
[
  ['dummyfunction',['DummyFunction',['../class_dummy_function.html',1,'DummyFunction'],['../class_dummy_function.html#a2f02bcf719d6660eda10e54f7135fc9a',1,'DummyFunction::DummyFunction()']]]
];
