var indexSectionsWithContent =
{
  0: "cdfghioprs",
  1: "cdfghopr",
  2: "cdfgios"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

